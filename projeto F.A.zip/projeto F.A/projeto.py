# Felipe Bechelli do Prado 
# GUSTAVO NOVAIS CHEIDA


def menu(cpf):
    while True:
        print("""
        |-------- MENU --------|
        1 - Consultar saldo     
        2 - Consultar extrato
        3 - Depositar
        4 - Sacar
        5 - Comprar criptomoedas
        6 - Vender criptomoedas
        7 - Atualizar cotação
        8 - Sair
        ----------------------
        """)
        escolha = int(input("Digite um número para prosseguir: "))
        if escolha == 1:
            Consultarsaldo()

        elif escolha == 2:
            Consultarextrato(cpf)

        elif escolha == 3:
            Depositar(cpf)

        elif escolha == 4:
            Sacar(cpf)

        elif escolha == 5:
            Comprarcriptomoedas(cpf)

        elif escolha == 6:
            Vendercriptomoedas(cpf)

        elif escolha == 7:
            Atualizarcotacao()

        elif escolha == 8:
            print()
            break
        else:
            print("Número inválido !!")

def menuADM():
    while True:
        print("""
        --------- MENU ADM---------
        1 - Cadastrar novo investidor
        2 - Excluir investidor
        3 - Cadastrar nova criptomoeda
        4 - Excluir criptomoeda
        5 - Consultar saldo de um investidor
        6 - Consultar extrato de um investidor
        7 - Atualizar cotação das criptomoedas
        8 - Sair
        --------------------------
        """)
        escolha = int(input("Digite um número para prosseguir: "))
        if escolha == 1:
            Cadastrarnovoinvestidor()

        elif escolha == 2:
            Excluirinvestidor()

        elif escolha == 3:
            Cadastrarnovacriptomoeda()

        elif escolha == 4:
            Excluircriptomoeda()

        elif escolha == 5:
            Consultarsaldodeuminvestidor()

        elif escolha == 6:
            Consultarextratodeuminvestidor()

        elif escolha == 7:
            Atualizarcotacaodascriptomoedas()

        elif escolha == 8:
            print()
            break
        else:
            print("Número inválido !!")

# ---------- Formatar valores -------------- #
def format_float(valor):
    # Converte o número para uma string com 10 casas decimais
    valor_str = f"{valor:.6f}".rstrip('0').rstrip('.')
    return valor_str
# ------------------------------------------- #

# -------- 2 parte do extrato ----------#
    
def parte2extrato(taxa):

    L = []
    L2 = []
    Reais = ""

    with open("investidores.txt","r") as arquivo2:
        dados2 = arquivo2.readlines()
        for linha in dados2:
            items = linha.strip().split(',')
            Reais = items[3]
            L = items[4:]
            
        
    with open("criptomoedas.txt","r") as arquivo2:
        dados2 = arquivo2.readlines()
        for linha in dados2:
            linha = linha.replace("R$","")
            items = linha.strip().split("    ")
            if items[1]:
                L2.append(items[0])

    dicionario = {}

    for i in range(len(L)):
        dicionario[L2[i]] = L[i]

    y = f"   TX: {taxa} REAL: {Reais} "
    for chave,valor in dicionario.items():
        y += f"{chave}: {valor} "
    
    return y
   

# ----- Complementa o extrato --- parte da taxa de compra e juros #

def juros(escolha,sinal):
    if escolha == 1:
        if sinal == '+':
 
            return 2/100
        else:
            return  3/100
        
    elif escolha == 2:
        if sinal == '+':
            return 1/100
        else:
            return 2/100
        
    elif escolha == 3:
        return 1/100
    else:
        return 0.0

# ---- Menu na compra da cripto moeda ------- Salva no extrato e modifica o saldo #

def menuCripto(cpf,sinal,senha):
    with open("criptomoedas.txt","r") as arquivo:
        dados =  arquivo.readlines()
        for linha in dados:
            items = linha.strip('R$').split("   ")
            if items[0] == "Reais":
                continue
            else:
                print("------------------------")
                print(f"{linha}")

    print("----------------------")
    escolha = int(input("Qual moeda deseja?: "))
    valor = float(input("Valor: "))

    #-----padrao do menu ---- #S

    with open("criptomoedas.txt","r") as arquivo:
        dados = arquivo.readlines()
        for linha in dados:
            linha = linha.replace('R$', '').strip()
            items = linha.split("    ")
            if len(items) >= 3 and items[3] == str(escolha):
                conversao = items[2]
                sigla = items[0]
                break
    
    #--------------------------#

    with open("investidores.txt","r") as arquivo:
        dados2 = arquivo.readlines()

    encontrado = False
    with open("investidores.txt","w") as arquivo:
        for linha2 in dados2:
            items2 = linha2.strip().split(',')
            if items2[0] == cpf: #reais
                nome = items2[2]
                if sinal == '+': #comprando reais para cripto
                    novo_saldo = float(items2[3]) - valor #Criptomoeda que vai comprar
                    if novo_saldo < 0:
                        print("Não possui dinheiro suficiente !!")
                        print()
                        arquivo.write(','.join(items2) + '\n')
                        continue
                    else:
                        encontrado = True
                        items2[3] = str(novo_saldo) #Reais 
                        items2[3 + escolha] = str(format_float((valor - juros(escolha,sinal)*valor)/float(conversao)))
                        linha2 = ','.join(items2) + '\n'
                        arquivo.write(linha2)
                else: #vendendo criptomoedas
                    novo_saldo = float(items2[3 + escolha]) - valor 
                    if novo_saldo < 0:
                        print("Não possui dinheiro suficiente !!")
                        print()
                        arquivo.write(','.join(items2) + '\n')
                        continue
                    else:
                        encontrado = True
                        items2[3] = str(format_float(float(items2[3]) + (valor - juros(escolha,sinal)*valor)*float(conversao))) #REAIS
                        items2[3 + escolha] = str(format_float(novo_saldo)) #CRIPTOMOEDA
                        linha2 = ','.join(items2) + '\n'
                        arquivo.write(linha2)
            else:
                arquivo.write(linha2)
    if encontrado == True:
        registrar_extrato(cpf,valor,nome,sinal,sigla,conversao,escolha,senha)
# ----------------------------------------- #

#-------- Colocar traço e ponto no cpf --------#
  
def mudanca_no_cpf(cpf):
    L = []
    cout = 0

    for i in cpf:
        L.append(i)
        cout+=1
        if cout  % 3 == 0 and cout % 9 != 0:
            L.append('.')

        if cout  % 9 == 0:
            L.append('-')
    
    novo_cpf = ''.join(L)
    return novo_cpf

#-----------------------------------------------#

#------------- HORARIO ----------#
def data():
    from datetime import datetime
    return datetime.now().strftime("%d-%m-%Y %H:%M:%S")
#--------------------------------#

def registrar_extrato(cpf,valor,nome,sinal,sigla,conversao,escolha,senha):

    #caso o investidor nao tiver investido ainda precisaremos de seu cpf e seu nome para adicionar no extrato
    # X --> REPRESENTA O NOME QUE VAMOS MANDAR PARA O EXTRATO
    # cpf --> PARA LOCALIZAR E FICAR MAIS FACIL, nao sei se é mais facil mas usei e deu certo
    # valor --> Indica a quantidade de dinheiro retirada na transacao
    # sinal --> operacao feita
    # tipo --> qual a moeda
    
    # se o investidor ja tiver feito alguma transacao    
    with open("extratos.txt","r") as extrato:
        dados = extrato.readlines()
        
    encontrado = 2
    with open("extratos.txt","w") as arquivo:
        for linha in dados:
            items = linha.strip().split(',')
            if items[0] == cpf:
                y = f"{data()} {sinal} {valor} {sigla} CT: {conversao} {parte2extrato(juros(escolha,sinal))}\n"
                linha = ','.join(items) + ',' + y
                encontrado -=1
            arquivo.write(linha)
        if encontrado == 2:
            y = f"{data()} {sinal} {valor} {sigla} CT: {conversao} {parte2extrato(juros(escolha,sinal))}\n"
            nova_linha = f"{cpf},{nome},{senha},{y}"
            arquivo.write(nova_linha)
        
            

#-------- VERIFICACAO INVESTIDOR OU ADM ------------#

def investidor(cpf, senha):
    # VERIFICACAO SE FOR USUARIO
    with open("investidores.txt", "r") as arquivo:
        dados = arquivo.readlines()  # pega todas as linhas
        for linha in dados:  # lê linha por linha
            items = linha.strip().split(",")  # items dentro da linha
            if items[0] == cpf and items[1] == senha:
                return True
                
    return False  # retorna False somente após verificar todas as linhas

def adm(cpf,senha):
    #VERIFICACAO SE FOR ADM
    with open("administradores.txt","r") as arquivo:
        dados = arquivo.readlines() #pega todas as linhas
        for linha in dados: #passa por cada linha
            items = linha.strip().split(",") #transforma essa linha em uma lista
            if items[0] == cpf and items[1] == senha:
                return True
            
    return False # retorna False somente após verificar todas as linhas

# -----------------------------------#

#--------FUNCOES INVESTIDOR ---------#

def Consultarsaldo():
    cpf = input("Digite o cpf (sem ponto e traco): ")

    L = [] #keys do dicionario
    L2 = [] #valores do dicionario

    with open("criptomoedas.txt","r") as arquivo: #pegar o nome das criptomoedas
        dados = arquivo.readlines()
        for linha in dados:
            linha = linha.replace("R$","")
            items = linha.split("    ")
            if items[1]:
                L.append(items[1])


    encontrado = 0
    with open("investidores.txt","r") as arquivo: #pegar os saldos do investidor
        dados = arquivo.readlines() 
        for linhas in dados: 
            items = linhas.strip().split(',')
            if items[0] == cpf:
                encontrado +=1
                cpf = items[0]
                nome = items[2]
                reais = items[3]
                L2 = list(items[4:])
                
    if encontrado == 0:
        print("Cpf não encontrado !!!") #caso não encontre o investidor
    else:
        dicionario = {}
        for i in range(len(L)):
            dicionario[L[i]] = L2[i]

        print()
        print(f"Nome: {nome}")
        print(f"CPF: {mudanca_no_cpf(cpf)}")
        print()
        print(f"Reais: {reais}")
        for chave,valor in dicionario.items():
            print(chave, ": ", valor)

def Consultarextrato(cpf):
    senha = input("Senha(min 6 dígitos): ")

    encontrado = 0
    with open("extratos.txt","r") as arquivo:
        dados = arquivo.readlines()
        for linhas in dados:
            items = linhas.strip().split(',')
            if items[0] == cpf and items[2] == senha:
                encontrado +=1
                print()
                print(f"Nome: {items[1]}")
                print(f"Cpf: {mudanca_no_cpf(cpf)}")
                print()
                L = items[3::]
                L.reverse()
                cout = 0
                for i in L:
                    if i == None or cout > 5:
                        break
                    else:
                        print(f"{i}")
                        cout +=1
    if encontrado == 0:
        print("Nenhuma transação realizada ainda!!!")
        
def Depositar(cpf):
    valor = float(input("Valor do depósito: "))

    with open("investidores.txt","r") as arquivo:
        dados = arquivo.readlines()
    
    encontrado = False
    with open("investidores.txt","w") as arquivo:
        for linha in dados:
            partes = linha.strip().split(',')
            if partes[0] == cpf:
                senha = partes[1]
                encontrado = True
                conversao = "0.0"
                sinal = '+'
                sigla = "REAL"
                escolha = 0
                nome = partes[2]
                novo_saldo = format_float(float(partes[3]) + valor)
                partes[3] = str(novo_saldo)
                print(f"Novo saldo: {novo_saldo}")          
                linha = ','.join(partes) + '\n'
            arquivo.write(linha)

    if encontrado == True:
        registrar_extrato(cpf,valor,nome,sinal,sigla,conversao,escolha,senha)
    
                
def Sacar(cpf): 
    valor = float(input("Valor de saque: "))

    with open("investidores.txt","r") as arquivo:
        dados = arquivo.readlines()

    encontrado = False
    with open("investidores.txt","w") as arquivo2:
        for linha in dados:
            items = linha.strip().split(',')
            if items[0] == cpf:
                nome = items[2]
                novo_saldo = float(items[3]) - valor
                if novo_saldo < 0:
                    print("Não possui dinheiro suficiente !!")
                    print()
                    linha = ','.join(items) + '\n'
                else:
                    encontrado = True
                    senha = items[1]
                    sinal = '-'
                    conversao = "0.0"
                    sigla = "REAL"
                    escolha = 0
                    items[3] = str(format_float(novo_saldo))
                    print(f"Novo saldo: {novo_saldo}")
                    linha = ','.join(items) + '\n'
            arquivo2.write(linha)

    if encontrado == True:
        registrar_extrato(cpf,valor,nome,sinal,sigla,conversao,escolha,senha)


def Comprarcriptomoedas(cpf): # decidi colocar o cpf caso alguem coloque a mesma senha 
                              # Para evitar erros na hora de ler, mais seguranca
    senha = input("Digite sua senha: ")

    encontrado = 2
    with open("investidores.txt","r") as arquivo:
        dados = arquivo.readlines()
        for linha in dados:
            items = linha.strip().split(',')
            if items[1] == senha and items[0] == cpf:
                senha1 = items[1]
                encontrado -=1
                break
        if encontrado == 2:
            print("Senha errada !!!")
        else:
            sinal = '+'
            menuCripto(cpf,sinal,senha1)


def Vendercriptomoedas(cpf):

    senha = input("Digite sua senha: ")

    encontrado = 2
    with open("investidores.txt","r") as arquivo:
        dados = arquivo.readlines()
        for linha in dados:
            items = linha.strip().split(',')
            if items[1] == senha and items[0] == cpf:
                senha1 = items[1]
                encontrado -=1
                break
        if encontrado == 2:
            print("Senha errada !!!")
        else:
            sinal = '-'
            menuCripto(cpf,sinal,senha1)

def Atualizarcotacao():
    print()

#-----------------------------------#

#----------FUNCOES ADM -----------#

def Cadastrarnovoinvestidor():

    cpf = input("Digite o cpf (sem ponto e traço): ")
    senha = input("Digite a senha (mínimo de 6 numeros): ")
    nome = input("Digite o nome: ")

    if len(cpf) != 11 or len(senha) < 6:
        print("Cpf ou senha inválidos !!")
    else:
        L = []
        with open("criptomoedas.txt","r") as arquivo:
            dados = arquivo.readlines()
            for linha in dados:
                linha = linha.replace('R$', '').strip()
                items = linha.split("    ")
                if items[3].isdigit():
                    L.append("0.0")

        with open("investidores.txt","a") as arquivo: # o 0.0 que tá adicionando é os reais da conta
            arquivo.write(f"{cpf},{senha},{nome},0.0,{','.join(L)}\n")#padrao: REAIS,BITCOIN,ETHEREUM,RIPPLE
        print("Investidor cadastrado com sucesso!")


def Excluirinvestidor():
    
    cpf = input("Digite o cpf do investidor: ")

    with open("investidores.txt","r") as arquivo:
        dados = arquivo.readlines()
    
    encontrado = 0
    with open("investidores.txt","w") as arquivo:
        for linha in dados:
            if cpf in linha:
                encontrado +=1
                del linha
                print("Investidor excluído !!!")
                continue
            arquivo.write(linha)
    
    if encontrado == 0:
        print("Investidor não localizado !!!")
    else:
        with open("extratos.txt","r") as arquivo:
            dados = arquivo.readlines()
        
        with open("extratos.txt","w") as arquivo:
            for linha in dados:
                items = linha.strip().split(',')
                if items[0] == cpf:
                    del linha
                    continue
                arquivo.write(linha)

def Cadastrarnovacriptomoeda():
    sigla = input("Digite a sigla da criptomoeda: ")
    nome = input("Qual o nome da criptomoedas: ")
    cotacao = input("Qual a taxa de cotação: ")
    numero = input("numero da nova moeda(seguindo a ardem das existentes): ")
    
    with open("criptomoedas.txt","r") as arquivo:
        dados = arquivo.readlines()

    repetido = 0
    with open("criptomoedas.txt","a") as arquivo: #verificacao já existe moeda com esse nome
        for linha in dados:
            items = linha.strip("R$").split('    ')
            if items[1] == nome:
                print("Nome de criptomoeda já existente !!")
                repetido +=1        
        if repetido == 0:
            print("Nova moeda cadastrada !!!")
            arquivo.write(f"{sigla}   R$ {nome}    {cotacao}    {numero}\n")
            with open("investidores.txt","r") as arquivo: #cadastrar nova moeda na conta dos investidores
                dados = arquivo.readlines()

            with open("investidores.txt","w") as arquivo:
                for linha in dados:
                    items = linha.strip().split(",")
                    linha = ",".join(items) + ",0.0" + '\n'
                    arquivo.write(linha)
                

def Excluircriptomoeda():
    nome = input("Digite o nome da criptomoeda: ") 

    with open("criptomoedas.txt","r") as arquivo:
        dados = arquivo.readlines()

    encontrado = 0
    with open("criptomoedas.txt","w") as arquivo:
        for linha in dados:
            if nome in linha:
                encontrado +=1
                del linha
                print("Criptomoeda excluída !!")
                continue
            arquivo.write(linha)

    if encontrado == 0:
        print("Criptomoeda não localizada !!")


def Consultarsaldodeuminvestidor():
    cpf = input("Digite o cpf (sem ponto e traco): ")

    L = []
    L2 = []

    with open("criptomoedas.txt","r") as arquivo:
        dados = arquivo.readlines()
        for linha in dados:
            linha = linha.replace("R$","").strip()
            items = linha.split("    ")
            if items[1]:
                L.append(items[1])


    encontrado = 0
    with open("investidores.txt","r") as arquivo:
        dados = arquivo.readlines() # ve todas as linhas
        for linhas in dados: #ve linha por linha 
            items = linhas.strip().split(',')
            if items[0] == cpf:
                encontrado +=1
                cpf = items[0]
                nome = items[2]
                reais = items[3]
                L2 = items[4:]
    if encontrado == 0:
        print("Cpf não encontrado !!!")

    dicionario = {}
    for i in range(len(L)):
        dicionario[L[i]] = L2[i]
    
    print(f"Nome: {nome}")
    print(f"CPF: {mudanca_no_cpf(cpf)}")
    print()
    print(f"Reais: {reais}")
    for chave,valor in dicionario.items():
        print(chave, ": ", valor)
            
def Consultarextratodeuminvestidor():
    cpf = input("Digite o cpf do investidor: ")

    encontrado = 0
    with open("extratos.txt","r") as arquivo:
        dados = arquivo.readlines()
        for linhas in dados:
            items = linhas.strip().split(',')
            if items[0] == cpf:
                encontrado +=1
                print()
                print(f"Nome: {items[2]}")
                print(f"Cpf: {mudanca_no_cpf(cpf)}")
                print()
                L = items[3::]
                L.reverse()
                cout = 0
                for i in L:
                    if i == None or cout > 5:
                        break
                    else:
                        print(f"{i}")
                        cout +=1
    if encontrado == 0:
        print("Cpf não encontrado ou não existe registro de transações!!!")

# aqui vai ser só para ver as açoes, mas por enquanto deixa que o adm muda a cotacao
#fazer dps a atualizacao cada vez que fizerem uma compra ou venda de criptomoedas
def Atualizarcotacaodascriptomoedas():

    from random import randint

    variacao = (randint(-5,5)/100)

    with open("criptomoedas.txt","r") as arquivo:
        dados = arquivo.readlines()

    with open("criptomoedas.txt","w") as arquivo:
        for linha in dados:
            linha = linha.replace("R$","")
            items = linha.split("    ")
            if items[2]:
                items[2] = 'R$ ' + str(format_float(float(items[2]) + (float(items[2]) * variacao)))
                linha = '    '.join(items)
            arquivo.write(linha)

    print("Atualizações feitas com sucesso !!!")   
#-----------------------------------#                 
    
while True:
    cpf = input("Cpf (sem ponto e traço): ")
    senha = input("senha(mínimo de 6 dígitos): ")
    if len(cpf) != 11 or len(senha) < 6:
        print()
        print("Cpf ou senha inválidos !!")
        print("Tente novamente.")
        print()
        continue
    
    if investidor(cpf, senha):
        menu(cpf)

    elif  adm(cpf,senha):
        menuADM()

    else:
        # passado na verificacao
        print("Usuário não cadastrado !!")
        continue